# faker

[![goproxy.cn](https://goproxy.cn/stats/<module-path>/badges/download-count.svg)](https://goproxy.cn)
