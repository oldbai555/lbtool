package main

import (
	"time"
)

func main() {
	time.Sleep(time.Hour)
	println("ok")
}
