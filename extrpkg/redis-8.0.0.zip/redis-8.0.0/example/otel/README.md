### OpenTelemetry Example 
Prints spans and metrics to the console.
#### To Run:
- `docker-compose up -d`
- `go run .`

When you're finished, be sure to run `docker-compose down` to shutdown
the redis server.

